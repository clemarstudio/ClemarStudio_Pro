@echo off
SETLOCAL EnableDelayedExpansion

:: Check for /uninstall flag
if "%~1"=="/uninstall" goto :Uninstall

:: =====================================================================
:: ClemarStudio Manual Installation Script
:: Equivalent to setup.iss — installs to User AppData (no Admin needed)
:: =====================================================================

SET "APP_NAME=ClemarStudio"
SET "TARGET_DIR=%AppData%\ClemarStudio"
SET "REVIT_BASE_DIR=%AppData%\Autodesk\Revit\Addins"

echo ---------------------------------------------------------
echo Installing %APP_NAME% for current user...
echo Target: %TARGET_DIR%
echo ---------------------------------------------------------

:: 1. Create App Directories (mirrors [Dirs] in setup.iss)
echo [+] Creating directories...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
for %%V in (2022 2023 2024 2025 2026 Common) do (
    if not exist "%TARGET_DIR%\%%V" mkdir "%TARGET_DIR%\%%V"
)

:: 2. Copy Common Files — revit_knowledge.bin (mirrors [Files] line 109)
echo [+] Copying Knowledge Base...
if exist "Common\revit_knowledge.bin" (
    copy /Y "Common\revit_knowledge.bin" "%TARGET_DIR%\Common\"
) else if exist "revit_knowledge.bin" (
    copy /Y "revit_knowledge.bin" "%TARGET_DIR%\Common\"
) else (
    echo [!] WARNING: revit_knowledge.bin not found. AI features may not work offline.
)

:: 3. Copy Payloads and Generate .addin files
:: Note: setup.iss uses HKLM registry check (IsRevitInstalled).
:: On IT-locked machines HKLM may be unreadable, so we also try
:: HKCU and the WOW6432Node fallback — matching DetectRevitInstall().

:: --- Revit 2022-2024 (.NET 4.8) ---
for %%Y in (2022 2023 2024) do (
    call :IsRevitInstalled %%Y
    if !ERRORLEVEL! EQU 0 (
        set "GUID="
        if "%%Y"=="2022" set "GUID=EADBCD71-4428-4C70-A296-C6B77D39D88D"
        if "%%Y"=="2023" set "GUID=13D7790D-4C69-4600-BF74-D37945AB954C"
        if "%%Y"=="2024" set "GUID=60DEF26C-B8C7-464D-94C4-9B2DE5F3088A"

        echo [+] Revit %%Y detected. Installing...
        if exist "Net48" (
            xcopy /S /Y "Net48\*.*" "%TARGET_DIR%\%%Y\" >nul
            call :CreateAddin %%Y !GUID!
        ) else (
            echo [!] ERROR: "Net48" source folder missing.
        )
    )
)

:: --- Revit 2025-2026 (.NET 8) ---
for %%Y in (2025 2026) do (
    call :IsRevitInstalled %%Y
    if !ERRORLEVEL! EQU 0 (
        set "GUID="
        if "%%Y"=="2025" set "GUID=E73982C8-7F54-4321-8EAA-0FB0FD1EE080"
        if "%%Y"=="2026" set "GUID=02FD367D-FFDE-4F31-BC5E-E60CBE518112"

        echo [+] Revit %%Y detected. Installing...
        if exist "Net8" (
            xcopy /S /Y "Net8\*.*" "%TARGET_DIR%\%%Y\" >nul
            call :CreateAddin %%Y !GUID!
        ) else (
            echo [!] ERROR: "Net8" source folder missing.
        )
    )
)

:: 4. Drop uninstall.bat into the installed location for easy user access
echo [+] Installing uninstaller...
if exist "uninstall.bat" (
    copy /Y "uninstall.bat" "%TARGET_DIR%\uninstall.bat" >nul
    echo   - Uninstaller placed at %TARGET_DIR%\uninstall.bat
) else (
    echo [!] WARNING: uninstall.bat not found next to installer. Skipping.
)

:: 6. Unblock files (Prevents 0x80131515 error on company PCs)
echo [+] Unblocking files...
powershell -Command "Get-ChildItem -Path '%TARGET_DIR%' -Recurse | Unblock-File" 2>nul

echo ---------------------------------------------------------
echo  Installation complete! 
echo  Please restart Revit to see the ClemarStudio tab.
echo ---------------------------------------------------------
pause
exit /b

:: =====================================================================
:: Helper: Detect Revit (mirrors DetectRevitInstall in setup.iss)
:: Checks HKLM (native), HKLM WOW6432Node, and HKCU as fallbacks
:: Returns ERRORLEVEL 0 = found, 1 = not found
:: =====================================================================
:IsRevitInstalled
SET "_YEAR=%~1"
SET "_KEY=SOFTWARE\Autodesk\Revit\Autodesk Revit %_YEAR%"

REG QUERY "HKLM\%_KEY%"                       >nul 2>&1 && exit /b 0
REG QUERY "HKLM\SOFTWARE\WOW6432Node\%_KEY%"  >nul 2>&1 && exit /b 0
REG QUERY "HKCU\%_KEY%"                       >nul 2>&1 && exit /b 0
exit /b 1

:: =====================================================================
:: Helper: Create .addin file (mirrors CurStepChanged in setup.iss)
:: Params: %1 = Year, %2 = GUID
:: =====================================================================
:CreateAddin
SET "YEAR=%~1"
SET "GUID=%~2"
SET "ADDIN_FILE=%REVIT_BASE_DIR%\%YEAR%\%APP_NAME%.addin"

if not exist "%REVIT_BASE_DIR%\%YEAR%" mkdir "%REVIT_BASE_DIR%\%YEAR%"

echo   - Generating %ADDIN_FILE%
(
echo ^<?xml version="1.0" encoding="utf-8" standalone="no"?^>
echo ^<RevitAddIns^>
echo   ^<AddIn Type="Application"^>
echo     ^<Name^>ClemarStudio Addins^</Name^>
echo     ^<Assembly^>%TARGET_DIR%\%YEAR%\ClemarStudio.dll^</Assembly^>
echo     ^<AddInId^>%GUID%^</AddInId^>
echo     ^<FullClassName^>ClemarStudio.App^</FullClassName^>
echo     ^<VendorId^>CLMR^</VendorId^>
echo     ^<VendorDescription^>ClemarStudio^</VendorDescription^>
echo   ^</AddIn^>
echo ^</RevitAddIns^>
) > "%ADDIN_FILE%"
exit /b

:: =====================================================================
:: Helper: Uninstall (mirrors [UninstallDelete] in setup.iss)
:: Run: install.bat /uninstall
:: =====================================================================
:Uninstall
echo [+] Removing .addin files...
for %%Y in (2022 2023 2024 2025 2026) do (
    if exist "%REVIT_BASE_DIR%\%%Y\%APP_NAME%.addin" (
        del /F /Q "%REVIT_BASE_DIR%\%%Y\%APP_NAME%.addin"
        echo   - Removed %REVIT_BASE_DIR%\%%Y\%APP_NAME%.addin
    )
)
echo [+] Uninstall complete. App files in %TARGET_DIR% were left intact.
pause
exit /b
