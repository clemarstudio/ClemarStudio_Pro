@echo off
SETLOCAL EnableDelayedExpansion

:: =====================================================================
:: ClemarStudio Uninstaller
:: Mirrors [UninstallDelete] section in setup.iss
:: Removes .addin registrations and all installed app files
:: =====================================================================

SET "APP_NAME=ClemarStudio"
SET "TARGET_DIR=%AppData%\ClemarStudio"
SET "REVIT_BASE_DIR=%AppData%\Autodesk\Revit\Addins"

echo ---------------------------------------------------------
echo  ClemarStudio Uninstaller
echo ---------------------------------------------------------
echo  This will remove:
echo    - All .addin files for Revit 2022-2026
echo    - All app files from %TARGET_DIR%
echo    - Your license token (you will need to re-activate)
echo    - The knowledge base (revit_knowledge.bin)
echo ---------------------------------------------------------
set /p CONFIRM=Are you sure? (Y/N): 
if /I not "%CONFIRM%"=="Y" (
    echo Uninstall cancelled.
    pause
    exit /b
)

echo.

:: 1. Remove .addin files (mirrors [UninstallDelete] in setup.iss)
echo [+] Removing Revit .addin files...
for %%Y in (2022 2023 2024 2025 2026) do (
    if exist "%REVIT_BASE_DIR%\%%Y\%APP_NAME%.addin" (
        del /F /Q "%REVIT_BASE_DIR%\%%Y\%APP_NAME%.addin"
        echo   - Removed Revit %%Y addin
    )
)

:: 2. Remove installed DLLs for each Revit version
echo [+] Removing installed app files...
for %%Y in (2022 2023 2024 2025 2026) do (
    if exist "%TARGET_DIR%\%%Y" (
        rmdir /S /Q "%TARGET_DIR%\%%Y"
        echo   - Removed %TARGET_DIR%\%%Y
    )
)

:: 3. Remove Common folder (knowledge base + any shared files)
if exist "%TARGET_DIR%\Common" (
    rmdir /S /Q "%TARGET_DIR%\Common"
    echo   - Removed knowledge base ^(Common^)
)

:: 4. Remove license token (license.token, ai_trial_count.bin)
if exist "%TARGET_DIR%\license.token" (
    del /F /Q "%TARGET_DIR%\license.token"
    echo   - Removed license token
)
if exist "%TARGET_DIR%\ai_trial_count.bin" (
    del /F /Q "%TARGET_DIR%\ai_trial_count.bin"
    echo   - Removed trial usage cache
)

:: 5. Remove WebView2 user data folder
if exist "%TARGET_DIR%\WebView2" (
    rmdir /S /Q "%TARGET_DIR%\WebView2"
    echo   - Removed WebView2 cache
)

:: 6. Final cleanup (Self-delete this script and wipe the ClemarStudio AppData folder)
echo [+] Final cleanup...
SET "SELF=%~f0"
SET "PARENT=%TARGET_DIR%"

echo ---------------------------------------------------------
echo  Uninstall complete. All files and folders removed.
echo  Restart Revit to take effect.
echo ---------------------------------------------------------
pause

:: Self-delete this script and wipe the entire ClemarStudio folder
(
  echo @echo off
  echo timeout /t 1 ^>nul
  echo del /F /Q "%SELF%" 2^>nul
  echo rmdir /S /Q "%PARENT%" 2^>nul
) > "%TEMP%\cs_cleanup.bat"
start /min cmd /c "%TEMP%\cs_cleanup.bat"
exit
